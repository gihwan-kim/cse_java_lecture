
public class W03_2_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int givenN;
		int count;
		int sum;
		sum=0;
		count=1;
		givenN=5;
		while(count<=givenN){
			sum = sum+count;
			System.out.println("1���� " + count +"������ ����"+sum+"�̴�.");
			count = count + 1;
	}
	}
}